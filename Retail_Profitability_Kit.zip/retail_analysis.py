
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load Data
df = pd.read_csv("retail_data.csv")

# Calculate Profit Margin
df["profit_margin"] = df["profit"] / df["sales"]

# Correlation
corr = df[["inventory_days", "profit_margin"]].corr()
print("Correlation:\n", corr)

# Heatmap
sns.heatmap(corr, annot=True, cmap="YlGnBu")
plt.title("Correlation: Inventory Days vs Profit Margin")
plt.show()
