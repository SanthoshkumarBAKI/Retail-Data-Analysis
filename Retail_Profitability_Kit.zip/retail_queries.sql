
-- 1. Total Profit and Margin by Category/Sub-category
SELECT category, sub_category,
       SUM(sales) AS total_sales,
       SUM(profit) AS total_profit,
       ROUND(SUM(profit) / NULLIF(SUM(sales), 0), 2) AS profit_margin
FROM retail_data
GROUP BY category, sub_category
ORDER BY profit_margin;

-- 2. Seasonal Profit Trend
SELECT MONTH(order_date) AS month,
       category,
       SUM(sales) AS monthly_sales,
       SUM(profit) AS monthly_profit
FROM retail_data
GROUP BY MONTH(order_date), category
ORDER BY month;
